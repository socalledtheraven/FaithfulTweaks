# [All information about it here](https://docs.compliancepack.net/pages/dungeons/alpha-img)
> Author: Juknum
