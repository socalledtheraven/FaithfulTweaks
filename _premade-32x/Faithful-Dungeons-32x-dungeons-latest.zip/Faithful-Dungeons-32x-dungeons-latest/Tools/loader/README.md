# [All information about it here](https://docs.compliancepack.net/pages/dungeons/loader-texture)
> Authors:  
> - Juknum  
> - [@CCCode](https://github.com/EvenTorset) for creating the blender model  
